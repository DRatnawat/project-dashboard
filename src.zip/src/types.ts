export type ChartType = 'line' | 'bar' | 'area' | 'pie';

export interface Widget {
  id: string;
  type: ChartType;
  title: string;
  data: any[];
  dataKey: string;
  layout: {
    x: number;
    y: number;
    w: number;
    h: number;
  };
  onModify?: (widget: Widget) => void;
}

export interface FilterState {
  title: string;
  type: ChartType | '';
  minValue: string;
  maxValue: string;
}