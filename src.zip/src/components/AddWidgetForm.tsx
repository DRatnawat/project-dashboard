import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import axios from 'axios';
import { Widget } from '../types';

// Axios client configuration
const client = axios.create({
  baseURL: 'https://0e13-103-83-254-78.ngrok-free.app/api/reports',
  headers: {
    'ngrok-skip-browser-warning': '69420',
  },
});

type DataPoint = {
  dataSource: string;
  field: string;
  aggregation: string;
  metricSource: string;
  metric: string;
};

type ChartType = 'line' | 'bar' | 'area' | 'pie';

interface AddWidgetFormProps {
  onAdd: (newWidget: Omit<Widget, 'id'>) => void;
  onClose: () => void;
}

const AddWidgetForm: React.FC<AddWidgetFormProps> = ({ onAdd, onClose }) => {
  const [title, setTitle] = useState<string>('');
  const [type, setType] = useState<ChartType>('line');
  const [dataPoint, setDataPoint] = useState<DataPoint>({
    dataSource: '',
    field: '',
    aggregation: '',
    metricSource: '',
    metric: '',
  });

  const [tables, setTables] = useState<string[]>([]);
  const [fields, setFields] = useState<string[]>([]);
  const [metrics, setMetrics] = useState<string[]>([]);
  const [metricSources, setMetricSources] = useState<Array<{
    id: string;
    relationshipType: string;
    scolumn: string;
    ttable: string;
    stable: string;
    tcolumn: string;
  }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch tables only once on mount
  useEffect(() => {
    const fetchTables = async () => {
      try {
        const response = await client.get('/fields');
        const uniqueTables = [...new Set(response.data.map((item: { entityName: string }) => item.entityName))] as string[];
        setTables(uniqueTables || []);
      } catch (error) {
        console.error('Error fetching tables:', error);
      }
    };

    fetchTables();
  }, []); // Empty dependency array means this runs once on mount

  // Combined fetch function for dependent data
  const fetchDependentData = async (dataSource: string, field?: string) => {
    setIsLoading(true);
    try {
      if (dataSource) {
        // Wrap each API call in a try-catch to handle individual failures
        try {
          const fieldsRes = await client.get(`/fields/${dataSource}`);
          setFields(fieldsRes.data.map((item: { columnName: string }) => item.columnName) || []);
        } catch (error) {
          console.error('Error fetching fields:', error);
          setFields([]);
        }

        try {
          const sourcesRes = await client.get(`/relations/${dataSource}`);
          setMetricSources(sourcesRes.data || []);
        } catch (error) {
          console.error('Error fetching metric sources:', error);
          setMetricSources([]);
        }

        if (field) {
          try {
            const metricsRes = await client.get(`/metrics/${dataSource}/${field}`);
            setMetrics(metricsRes.data || []);
          } catch (error) {
            console.error('Error fetching metrics:', error);
            setMetrics([]);
          }
        }
      }
    } catch (error) {
      console.error('Error in fetchDependentData:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Simplified updateDataPoint function
  const handleFieldChange = (field: keyof DataPoint, value: string) => {
    try {
      setDataPoint(prev => {
        const newDataPoint = { ...prev, [field]: value };
        
        // Clear dependent fields
        if (field === 'dataSource') {
          newDataPoint.field = '';
          newDataPoint.metricSource = '';
          newDataPoint.metric = '';
          // Use setTimeout to avoid state update conflicts
          setTimeout(() => {
            fetchDependentData(value);
          }, 0);
        } else if (field === 'field') {
          newDataPoint.metric = '';
          if (newDataPoint.dataSource && value) {
            setTimeout(() => {
              fetchDependentData(newDataPoint.dataSource, value);
            }, 0);
          }
        }
        
        return newDataPoint;
      });
    } catch (error) {
      console.error('Error in handleFieldChange:', error);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    onAdd({
      type,
      title,
      data: [dataPoint],
      dataKey: 'field',
      layout: { x: 0, y: 0, w: 6, h: 4 },
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md relative">
        {/* Loading overlay */}
        {isLoading && (
          <div className="absolute inset-0 bg-white bg-opacity-50 flex items-center justify-center z-10">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        )}

        {/* Form content */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Create New Widget</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            disabled={isLoading}
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700">Widget Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="Enter widget title"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700">Chart Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as ChartType)}
              className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="line">Line Chart</option>
              <option value="bar">Bar Chart</option>
              <option value="area">Area Chart</option>
              <option value="pie">Pie Chart</option>
            </select>
          </div>

          <div className="space-y-4 border-b pb-4">
            <div>
              <label className="block text-sm font-bold text-gray-700">Data Source</label>
              <select
                value={dataPoint.dataSource}
                onChange={(e) => handleFieldChange('dataSource', e.target.value)}
                className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                disabled={isLoading}
                required
              >
                <option value="">Select Data Source</option>
                {tables.map((table) => (
                  <option key={table} value={table}>{table}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700">Field</label>
              <select
                value={dataPoint.field}
                onChange={(e) => handleFieldChange('field', e.target.value)}
                className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                disabled={isLoading || !dataPoint.dataSource}
              >
                <option value="">Select Field</option>
                {fields.map((field) => (
                  <option key={field} value={field}>{field}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700">Aggregation</label>
              <select
                value={dataPoint.aggregation}
                onChange={(e) => handleFieldChange('aggregation', e.target.value)}
                className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select Aggregation</option>
                <option value="sum">Sum</option>
                <option value="avg">Average</option>
                <option value="min">Minimum</option>
                <option value="max">Maximum</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700">Metric Source</label>
              <select
                value={dataPoint.metricSource}
                onChange={(e) => handleFieldChange('metricSource', e.target.value)}
                className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select Metric Source</option>
                {metricSources.map((source) => (
                  <option key={source.id} value={source.ttable}>
                    {source.ttable}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700">Field</label>
              <select
                value={dataPoint.metric}
                onChange={(e) => handleFieldChange('metric', e.target.value)}
                className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                disabled={isLoading || !dataPoint.metricSource}
              >
                <option value="">Select Field</option>
                {fields.map((field) => (
                  <option key={field} value={field}>{field}</option>
                ))}
              </select>
            </div>

            <div className="flex justify-end mt-6">
              <button
                type="submit"
                className="px-4 py-2 bg-blue-500 text-white font-bold rounded hover:bg-blue-600"
              >
                Create Widget
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddWidgetForm;
