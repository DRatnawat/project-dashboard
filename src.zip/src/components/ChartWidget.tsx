import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { Widget } from '../types';
import { useState } from 'react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

interface ChartWidgetProps {
  widget: Widget;
}

// Add sample data
const SAMPLE_DATA = {
  line: [
    { name: 'Jan', value1: 400, value2: 240 },
    { name: 'Feb', value1: 300, value2: 139 },
    { name: 'Mar', value1: 200, value2: 980 },
    { name: 'Apr', value1: 278, value2: 390 },
    { name: 'May', value1: 189, value2: 480 },
    { name: 'Jun', value1: 239, value2: 380 },
  ],
  bar: [
    { name: 'Q1', sales: 4000, profit: 2400 },
    { name: 'Q2', sales: 3000, profit: 1398 },
    { name: 'Q3', sales: 2000, profit: 9800 },
    { name: 'Q4', sales: 2780, profit: 3908 },
  ],
  area: [
    { name: '2019', users: 4000, sessions: 2400 },
    { name: '2020', users: 3000, sessions: 1398 },
    { name: '2021', users: 2000, sessions: 9800 },
    { name: '2022', users: 2780, sessions: 3908 },
    { name: '2023', users: 1890, sessions: 4800 },
  ],
  pie: [
    { name: 'Mobile', value: 400 },
    { name: 'Desktop', value: 300 },
    { name: 'Tablet', value: 200 },
    { name: 'Other', value: 100 },
  ],
};

// Add new interface for chart settings
interface ChartSettings {
  title: string;
  type: 'line' | 'bar' | 'area' | 'pie';
  dataKeys: string[];
}

export default function ChartWidget({ widget }: ChartWidgetProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [chartSettings, setChartSettings] = useState<ChartSettings>({
    title: widget.title,
    type: widget.type,
    dataKeys: Array.isArray(widget.dataKey) ? widget.dataKey : [widget.dataKey],
  });

  const handleEditSave = (newSettings: ChartSettings) => {
    setChartSettings(newSettings);
    setIsEditing(false);
    widget.onModify?.({
      ...widget,
      title: newSettings.title,
      type: newSettings.type,
      dataKey: newSettings.dataKeys,
    });
  };

  const renderChart = (): JSX.Element => {
    // Replace console.log with data selection
    const chartData = SAMPLE_DATA[widget.type] || widget.data;
    
    // If no data provided, use sample data
    if (!widget.data || widget.data.length === 0) {
      if (!chartData) {
        return <div>No data available to display.</div>;
      }
    }

    const dataKeys = Array.isArray(widget.dataKey) 
      ? widget.dataKey 
      : widget.dataKey 
      ? [widget.dataKey]
      : widget.type === 'line' ? ['value1', 'value2']
      : widget.type === 'bar' ? ['sales', 'profit']
      : widget.type === 'area' ? ['users', 'sessions']
      : ['value'];

    switch (widget.type) {
      case 'line':
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            {dataKeys.map((key, index) => (
              <Line
                key={index}
                type="monotone"
                dataKey={key}
                stroke={COLORS[index % COLORS.length]}
              />
            ))}
          </LineChart>
        );
      case 'bar':
        return (
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            {dataKeys.map((key, index) => (
              <Bar
                key={index}
                dataKey={key}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </BarChart>
        );
      case 'area':
        return (
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            {dataKeys.map((key, index) => (
              <Area
                key={index}
                type="monotone"
                dataKey={key}
                stroke={COLORS[index % COLORS.length]}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </AreaChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={chartData}
              dataKey={dataKeys[0]}
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius="80%"
              label
            >
              {chartData.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        );
      default:
        return <div>Invalid chart type</div>;
    }
  };

  return (
    <div className="h-full w-full p-4 bg-white rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold">{widget.title}</h3>
        <button 
          onClick={() => setIsEditing(true)}
          disabled={!widget.onModify}
          className={`px-3 py-1 text-sm border rounded-md transition-colors ${
            widget.onModify 
              ? 'text-blue-600 hover:text-blue-800 border-blue-600 hover:border-blue-800 cursor-pointer'
              : 'text-gray-400 border-gray-400 cursor-not-allowed'
          }`}
        >
          Edit
        </button>
      </div>
      <div className="h-[calc(100%-2rem)]">
        {widget.type && (
          <ResponsiveContainer width="100%" height="100%">
            {renderChart()}
          </ResponsiveContainer>
        )}
      </div>

      {/* Add Edit Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-96">
            <h2 className="text-xl font-bold mb-4">Edit Chart</h2>
            <form onSubmit={(e) => {
              e.preventDefault();
              handleEditSave(chartSettings);
            }}>
              <div className="mb-4">
                <label className="block mb-2">Title</label>
                <input
                  type="text"
                  value={chartSettings.title}
                  onChange={(e) => setChartSettings({
                    ...chartSettings,
                    title: e.target.value
                  })}
                  className="w-full border p-2 rounded"
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Chart Type</label>
                <select
                  value={chartSettings.type}
                  onChange={(e) => setChartSettings({
                    ...chartSettings,
                    type: e.target.value as any
                  })}
                  className="w-full border p-2 rounded"
                >
                  <option value="line">Line Chart</option>
                  <option value="bar">Bar Chart</option>
                  <option value="area">Area Chart</option>
                  <option value="pie">Pie Chart</option>
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-100"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
